lancer le fichier FlyingAugustin.exe pour lancer le jeu.

comment jouer
-----------------------------
utiliser le clic de la souris ou la barre espace pour sauter.

passez entre les tuyaux et restez sur l'écran pour gagner autant de points que possible.
Le portail violet vous téléporte en avant, et apparaît si vous êtes trop en arrière.

un easter egg est caché, arriverez-vous à le trouver ?